package com.chenshiyuan_199050801.passwordmanager;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private EditText editText;
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editText=(EditText) findViewById(R.id.editText);

        findView();
    }
    //跳转至PasswordList页面
    private void findView(){
        editText=(EditText) findViewById(R.id.editText);
        Button button=(Button) findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(editText.getText().toString())){
                    AlertDialog alert=new AlertDialog.Builder(LoginActivity.this).create();
                    alert.setTitle("系统提示");
                    alert.setMessage("密码不能为空");
                    alert.show();
                }else {
                    if (editText.getText().toString().equals("admin")){
                        Intent i=new Intent(LoginActivity.this,PasswordListActivity.class);
                        //启动，利用startActivity
                        startActivity(i);
                    }else{
                        AlertDialog alert2=new AlertDialog.Builder(LoginActivity.this).create();
                        alert2.setTitle("系统提示");
                        alert2.setMessage("密码出错！");
                        alert2.show();
                    }
                }
            }
        });
    }
}
