package com.chenshiyuan_199050801.passwordmanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.chenshiyuan_199050801.passwordmanager.database.PasswordBaseHelper;
import com.chenshiyuan_199050801.passwordmanager.database.PasswordCursorWrapper;
import com.chenshiyuan_199050801.passwordmanager.database.PasswordDbSchema;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PasswordLab {
    private static PasswordLab sPasswordLab;
    private Context mContext;
    private SQLiteDatabase mDatabase;

    //存储Password的列表
    public static PasswordLab get(Context context){
        if (sPasswordLab==null){
            sPasswordLab=new PasswordLab(context);
        }
        return sPasswordLab;
    }
    private PasswordLab(Context context) {
        mContext = context.getApplicationContext();
        mDatabase=new PasswordBaseHelper(mContext).getWritableDatabase();
    }
    //得到整个列表
    public List<Password> getmPassword(){
        List<Password> passwords = new ArrayList<>();
        PasswordCursorWrapper cursor = (PasswordCursorWrapper) queryPassword(null, null);
        try {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                passwords.add(cursor.getPassword());
                cursor.moveToNext();
            }
        } finally {
            cursor.close();
        }
        return passwords;
    }
    //根据UUID来查找某个password记录
    public Password getPassword(UUID id){
        PasswordCursorWrapper cursor=(PasswordCursorWrapper) queryPassword(
                PasswordDbSchema.PasswordTable.Cols.UUID+"=?",
                new String[]{id.toString()}
                );
        try{
            if (cursor.getCount()==0){
                return null;
            }
        cursor.moveToFirst();
            return cursor.getPassword();
        }finally {
            cursor.close();
        }
    }



    //把一个Password对象添加到password列表中
    public void addPassword(Password password){
        ContentValues values=getContentValues(password);
        mDatabase.insert(PasswordDbSchema.PasswordTable.NAME,null,values);
    }
    public void removePassword(Password password){
        String uuidString=password.getId().toString();
        mDatabase.delete(PasswordDbSchema.PasswordTable.NAME,PasswordDbSchema.PasswordTable.Cols.UUID+ "=?",
                new String[]{uuidString});
    }
    private static ContentValues getContentValues(Password password) {
        ContentValues values=new ContentValues();
        values.put(PasswordDbSchema.PasswordTable.Cols.UUID,password.getId().toString());
        values.put(PasswordDbSchema.PasswordTable.Cols.TITLE,password.getTitle());
        values.put(PasswordDbSchema.PasswordTable.Cols.PAWORD,password.getmPassword());
        return values;
    }
    void updatePassword(Password password){
        String uuidString = password.getId().toString();
        ContentValues values=getContentValues(password);
        mDatabase.update(PasswordDbSchema.PasswordTable.NAME,values,
                PasswordDbSchema.PasswordTable.Cols.UUID+ "=?",
                new String[]{uuidString});
    }
    private Cursor queryPassword(String whereClause, String[] whereArgs) {
        Cursor cursor = mDatabase.query(
                PasswordDbSchema.PasswordTable.NAME,
                null, // Columns - null selects all column
                whereClause,
                whereArgs,
                null, // groupBy
                null, // having
                null  // orderBy
        );
        return new PasswordCursorWrapper(cursor);
    }


}
