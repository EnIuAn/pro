package com.chenshiyuan_199050801.passwordmanager;

import java.util.UUID;

public class Password {
    private UUID mId;
    private String mTitle;
    private String mPassword;

    public String getmPassword() {
        return mPassword;
    }

    public void setmPassword(String mPassword) {
        this.mPassword = mPassword;
    }

    public Password()
    {
        this(UUID.randomUUID());
    }
    public Password(UUID uuid){
        mId=uuid;
    }

    public UUID getId() {
        return mId;
    }


    public void setId(UUID Id) {
        mId = Id;
    }

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String Title) {
        this.mTitle = Title;
    }

}
