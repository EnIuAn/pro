package com.chenshiyuan_199050801.passwordmanager.database;

import android.database.Cursor;
import android.database.CursorWrapper;

import com.chenshiyuan_199050801.passwordmanager.Password;

import java.util.UUID;

//游标获取
public class PasswordCursorWrapper extends CursorWrapper {

    public PasswordCursorWrapper(Cursor cursor) {
        super(cursor);
    }

    public Password getPassword(){
        String uuidString = getString(getColumnIndex(PasswordDbSchema.PasswordTable.Cols.UUID));
        String title = getString(getColumnIndex(PasswordDbSchema.PasswordTable.Cols.TITLE));
        String paword = getString(getColumnIndex(PasswordDbSchema.PasswordTable.Cols.PAWORD));
        Password password=new Password(UUID.fromString(uuidString));
        password.setTitle(title);
        return password;
    }
}
