package com.chenshiyuan_199050801.passwordmanager;

import androidx.fragment.app.Fragment;

public class PasswordListActivity extends SingleFragmentActivity {

    @Override
    protected Fragment createFragment(){
        return new PasswordFragment();
    }
}
