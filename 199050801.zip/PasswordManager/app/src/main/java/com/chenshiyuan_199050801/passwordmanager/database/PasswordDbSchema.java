package com.chenshiyuan_199050801.passwordmanager.database;

//表结构
public class PasswordDbSchema {
    public static final class PasswordTable{
        public static final String NAME="passwords";
        public static final class Cols {
            public static final String UUID = "uuid";
            public static final String TITLE = "title";
            public static final String PAWORD="psword";
        }
    }
}
