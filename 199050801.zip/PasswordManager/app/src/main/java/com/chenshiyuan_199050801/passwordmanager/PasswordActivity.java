package com.chenshiyuan_199050801.passwordmanager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import java.util.UUID;

public class PasswordActivity extends SingleFragmentActivity {

    public static final String EXTRA_PASSWORD_ID="com.android.passwordmanager.password_id";
    @Override
    protected Fragment createFragment() {
        UUID passwordID=(UUID)getIntent().getSerializableExtra(EXTRA_PASSWORD_ID);
        return PasswordFragment.newInstance(passwordID);
    }
    public static Intent newIntent(Context packageContext, UUID passwordID){
        Intent intent=new Intent(packageContext,PasswordActivity.class);
        intent.putExtra(EXTRA_PASSWORD_ID,passwordID);
        return intent;
    }
}
