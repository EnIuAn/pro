package com.chenshiyuan_199050801.passwordmanager;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import java.util.List;
import java.util.UUID;

public class PasswordPagerActivity extends AppCompatActivity {
    private static final String EXTRA_PASSWORD_ID="com.chenshiyuan_199050801.passwordmanager.password_id";
    public static final String EXTRA_SUBTITLE_STAT="com.chenshiyuan_199050801.passwordmanager.subtitle_stat";
    private ViewPager mViewPager;
    private List<Password> mPasswords;

    @Override//重写onCreate方法
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actyvity_password_pager);

        //取出PasswordFragment中传过来的密码记录ID
        UUID passwordID=(UUID) getIntent().getSerializableExtra(EXTRA_PASSWORD_ID);
        mViewPager=findViewById(R.id.password_view_pager);
        mPasswords=PasswordLab.get(this).getmPassword();
        FragmentManager fragmentManager=getSupportFragmentManager();
        mViewPager.setAdapter(new FragmentStatePagerAdapter(fragmentManager) {
            @NonNull
            @Override
            public Fragment getItem(int position) {
                Password password=mPasswords.get(position);
                //根据当前定位到的笔记，把记录ID传给PasswordFragment，以显示明细
                return PasswordFragment.newInstance(password.getId());
            }

            @Override
            public int getCount() {
                return mPasswords.size();
            }
        });
        //找到当前点击的Password，然后把viewpager的项配置为该Password
        for (int i = 0; i < mPasswords.size(); i++) {
            if (mPasswords.get(i).getId().equals(passwordID)) {
                mViewPager.setCurrentItem(i);
                break;
            }
        }
    }
    //定义一个静态方法，用来产生一个新的Intent实例，该实例把笔记的ID的intent传递给PasswordPagerActivity
    public static Intent newIntent(Context packageContext, UUID passwordID) {
        Intent intent = new Intent(packageContext, PasswordPagerActivity.class);
        intent.putExtra(EXTRA_PASSWORD_ID, passwordID);
        return intent;
    }
    @Override
    public Intent getParentActivityIntent() {
        Intent parentIntent = getIntent();

        Boolean subtitleShow = parentIntent.getBooleanExtra(EXTRA_SUBTITLE_STAT, true);
        Intent newIntent = null;
        try {
            newIntent = new Intent(PasswordPagerActivity.this,
                    Class.forName("com.chenshiyuan_199050801.passwordmanager.PasswordListActivity"));
            newIntent.putExtra(EXTRA_SUBTITLE_STAT, subtitleShow);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return newIntent;
    }
}
