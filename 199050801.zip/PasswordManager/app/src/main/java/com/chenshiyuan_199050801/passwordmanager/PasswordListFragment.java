package com.chenshiyuan_199050801.passwordmanager;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PasswordListFragment extends Fragment {
    private RecyclerView mPasswordRecyclerView;
    private PasswordAdapter mAdapter;
    private boolean mSubtitleVisible;
    private static final String SAVED_SUBTITLE_VISIBLE = "subtitle";

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_password_list, container, false);
        mPasswordRecyclerView = view.findViewById(R.id.password_recycler_view);
        mPasswordRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mSubtitleVisible = getActivity().getIntent().getBooleanExtra(PasswordPagerActivity.EXTRA_SUBTITLE_STAT, true);
        if (savedInstanceState != null) {
            mSubtitleVisible = savedInstanceState.getBoolean(SAVED_SUBTITLE_VISIBLE);
        }
        //更新UI的显示
        updateUI();
        return view;
    }

    //第一个内部类，注意此处类声明时的编码语法
    private class PasswordHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView mTitleTextView;
        private TextView mPasswordTextView;
        private Password mPassword;

        public PasswordHolder(LayoutInflater inflater,ViewGroup parent){
            super(inflater.inflate(R.layout.list_item_password,parent,false));
            //实例化这两个变量
            mTitleTextView=itemView.findViewById(R.id.password_title);
            mPasswordTextView=itemView.findViewById(R.id.password_detail);
            //调用点击事件
            itemView.setOnClickListener(this);
        }
        //定义一个数据绑定方法
        public void bind(Password password){
            mPassword=password;
            mTitleTextView.setText(mPassword.getTitle());
            mPasswordTextView.setText(mPassword.getmPassword());
        }

        @Override
        public void onClick(View v) {
            //创建PasswordPagerActivity实例，并把当前笔记记录的ID传过去
            Intent intent = PasswordPagerActivity.newIntent(getActivity(), mPassword.getId());
            Bundle args = new Bundle();
            args.putSerializable("password_id", mPassword.getId());
            PasswordListFragment listFragment = new PasswordListFragment();
            listFragment.setArguments(args);
            startActivity(intent);
        }
    }

    //Adapter内部类
    private class PasswordAdapter extends RecyclerView.Adapter<PasswordHolder>{
        private List<Password> mPasswords;

        public PasswordAdapter(List<Password> passwords){
            mPasswords=passwords;
        }
        @NonNull
        @Override
        public PasswordHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new PasswordHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(@NonNull PasswordHolder holder, int position) {
            Password password = mPasswords.get(position);//得到位置
            holder.bind(password);
        }

        @Override
        public int getItemCount() {
            return mPasswords.size();
        }
        public void setmPasswords(List<Password> passwords){
            mPasswords=passwords;
        }
    }
    //更新界面的函数
    private void updateUI() {
        PasswordLab passwordLab = PasswordLab.get(getActivity());
        List<Password> passwords = passwordLab.getmPassword();
        if (mAdapter == null) {
            mAdapter = new PasswordAdapter(passwords);
            //把recyclerview与Adapter两者绑定在一起
            mPasswordRecyclerView.setAdapter(mAdapter);
        } else {
            mAdapter.notifyDataSetChanged();
            mAdapter.setmPasswords(passwords);
        }
        updateSubtitle();
    }

    @Override
    public void onResume() {
        super.onResume();
        updateUI();
    }
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.fragment_password_list, menu);
        MenuItem subtitleItem = menu.findItem(R.id.show_subtitle);
        if (mSubtitleVisible) {
            subtitleItem.setTitle(R.string.hide_subtitle);
        } else {
            subtitleItem.setTitle(R.string.show_subtitle);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.new_password:
                Password password = new Password();
                PasswordLab.get(getActivity()).addPassword(password);
                Intent intent = PasswordPagerActivity
                        .newIntent(getActivity(), password.getId());
                startActivity(intent);
                return true;
            case R.id.show_subtitle:
                mSubtitleVisible = !mSubtitleVisible;
                updateSubtitle();
                getActivity().invalidateOptionsMenu();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void updateSubtitle() {
        PasswordLab passwordLab = PasswordLab.get(getActivity());
        int passwordCount = passwordLab.getmPassword().size();//得到记录
        String subtitle = getString(R.string.subtitle_format, passwordCount);
        if (!mSubtitleVisible) {
            subtitle = null;
        }
        AppCompatActivity activity = (AppCompatActivity) getActivity();
        activity.getSupportActionBar().setSubtitle(subtitle);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(SAVED_SUBTITLE_VISIBLE, mSubtitleVisible);
    }
}
